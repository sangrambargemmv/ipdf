
export interface ImageFile {
  id: string;
  file: File;
  previewUrl: string;
}
